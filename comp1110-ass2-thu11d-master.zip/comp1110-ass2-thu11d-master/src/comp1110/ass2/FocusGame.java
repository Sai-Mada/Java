package comp1110.ass2;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

/**
 * This class provides the text interface for the IQ Focus Game
 * <p>
 * The game is based directly on Smart Games' IQ-Focus game
 * (https://www.smartgames.eu/uk/one-player-games/iq-focus)
 */
public class FocusGame {

    /**
     * Determine whether a piece placement is well-formed according to the
     * following criteria:
     * - it consists of exactly four characters
     * - the first character is in the range a .. j (shape)
     * - the second character is in the range 0 .. 8 (column)
     * - the third character is in the range 0 .. 4 (row)
     * - the fourth character is in the range 0 .. 3 (orientation)
     *
     * @param piecePlacement A string describing a piece placement
     * @return True if the piece placement is well-formed
     */
    static boolean isPiecePlacementWellFormed(String piecePlacement) {
        // FIXME Task 2: determine whether a piece placement is well-formed

        // written by Sai Mada.

        if (piecePlacement.length()!=4) return false;

        char first = piecePlacement.charAt(0);
        int second = Character.getNumericValue(piecePlacement.charAt(1));
        int third = Character.getNumericValue(piecePlacement.charAt(2));
        int fourth = Character.getNumericValue(piecePlacement.charAt(3));

        if (!(first >= 'a' && first <= 'j')) return false;
        if (!(second >= 0 && second <= 8)) return false;
        if (!(third >= 0 && third <= 4)) return false;
        if (!(fourth >= 0 && fourth <= 3)) return false;

        return true;
    }

    /**
     * Determine whether a placement string is well-formed:
     * - it consists of exactly N four-character piece placements (where N = 1 .. 10);
     * - each piece placement is well-formed
     * - no shape appears more than once in the placement
     *
     * @param placement A string describing a placement of one or more pieces
     * @return True if the placement is well-formed
     */
    public static boolean isPlacementStringWellFormed(String placement) {
        // written by Sai Mada.

        int len = placement.length();

        // if n placement place
        if (len % 4 != 0 || len / 4 < 1 || len / 4 > 10){
            return false;
        }

        // if every piece is well-formed
        for (int i = 0; i < len; i+=4){
            if (!isPiecePlacementWellFormed(placement.substring(i, i+4))){
                return false;
            }
        }

        // if every piece is unique on shape
        for (int i=0; i < len; i+=4){
            for (int j = 0; j < len; j+=4){
                if (i != j && placement.charAt(i) == placement.charAt(j)){
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * Determine whether a placement string is valid.
     * <p>
     * To be valid, the placement string must be:
     * - well-formed, and
     * - each piece placement must be a valid placement according to the
     * rules of the game:
     * - pieces must be entirely on the board
     * - pieces must not overlap each other
     *
     * @param placement A placement string
     * @return True if the placement sequence is valid
     */
    public static boolean isPlacementStringValid(String placement) {
        // FIXME Task 5: determine whether a placement string is valid
        // written by Qianrui Ma.

        if (!isPlacementStringWellFormed(placement)) {
            System.out.println("not well formed");
            return false;
        }

        ArrayList<Shape> ss = ShapeConfig.getShapes(placement);

        // in the board;
        for (Shape s : ss) {
            if (!s.inBoard()) {
                System.out.println("not in board");
                return false;
            }
        }

        // test overlap;
        for (Shape s : ss) {
            for (Shape si : ss) {
                if (s != si && s.overlap(si)) {
                    System.out.println("overlap");
                    return false;
                }

            }
        }

        return true;
    }

    /**
     * Given a string describing a placement of pieces and a string describing
     * a challenge, return a set of all possible next viable piece placements
     * which cover a specific board cell.
     * <p>
     * For a piece placement to be viable
     * - it must be valid
     * - it must be consistent with the challenge
     *
     * @param placement A viable placement string
     * @param challenge The game's challenge is represented as a 9-character string
     *                  which represents the color of the 3*3 central board area
     *                  squares indexed as follows:
     *                  [0] [1] [2]
     *                  [3] [4] [5]
     *                  [6] [7] [8]
     *                  each character may be any of
     *                  - 'R' = RED square
     *                  - 'B' = Blue square
     *                  - 'G' = Green square
     *                  - 'W' = White square
     * @param col       The cell's column.
     * @param row       The cell's row.
     * @return A set of viable piece placements, or null if there are none.
     */
    static Set<String> getViablePiecePlacements(String placement, String challenge, int col, int row) {
        // FIXME Task 6: determine the set of all viable piece placements given existing placements and a challenge
        // written by Qianrui Ma.

        Set<String> pieces = new HashSet<>();
        Shape CShape = ShapeConfig.getChallengeShape(challenge);
        // generate all possible pieces and test each of them
        for (char a = 'a'; a <= 'j'; a++) {
            for (int r = 0; r < 4; r++) {
                for (int x = 0; x < 9; x++) {
                    for (int y = 0; y < 5; y++) {
                        String piece = "" + a + x + y + r;
                        Shape candidate = ShapeConfig.getShape(piece);
                        // test if it covers the specific location
                        if (!candidate.contains(new Vector(col, row))) {
                            continue;
                        }
                        // test if well placement
                        if (isPlacementStringValid(placement + piece) && candidate.coexist(CShape)) {
                            pieces.add(piece);
                        }
                    }
                }
            }
        }
        // return null for empty
        if (pieces.isEmpty()) {
            return null;
        }
        return pieces;
    }

    /**
     * Return the canonical encoding of the solution to a particular challenge.
     * <p>
     * A given challenge can only solved with a single placement of pieces.
     * <p>
     * Since some piece placements can be described two ways (due to symmetry),
     * you need to use a canonical encoding of the placement, which means you
     * must:
     * - Order the placement sequence by piece IDs
     * - If a piece exhibits rotational symmetry, only return the lowest
     * orientation value (0 or 1)
     *
     * @param challenge A challenge string.
     * @return A placement string describing a canonical encoding of the solution to
     * the challenge.
     */
    // FIXME Task 9: determine the solution to the game, given a particular challenge

    
    public static String getSolution(String challenge) {
        //writen by Sai Mada.
        // The aim is to get a canonical encoding of the solution to the given challenge.
        // The approach is to maintain a string with all the pieces as we go through the board adding pieces
        // note that f and g are symmetrical in certain rotations

        // This string will store each piece we try out when looking for a solution
        String placement = "";

        // this string builder generates remaining pieces in our incomplete game
        StringBuilder str = new StringBuilder();

        // this array list will store all the remaining empty locations
        ArrayList<Character> remainingLocations = new ArrayList<>(); // all locations(char)

        // All rotations range fom 0-3
        // All pieces from A to J
        String allRotations = "0123";
        String allPieces = "abcdefghij";

        // These are all possible pieces on the board ranging from 1 to 40
        int [] allPossiblePieces = new int[40];
        for (int i = 1; i<=40; i++){
            allPossiblePieces[i-1] = i;
        }
        return null;

    }
}
