package comp1110.ass2;

public enum Color {
    // written by Qianrui Ma.
    Green,
    Blue,
    White,
    Red
}
