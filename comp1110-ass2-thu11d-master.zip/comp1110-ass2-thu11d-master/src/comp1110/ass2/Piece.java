package comp1110.ass2;

import static comp1110.ass2.Color.*;

public class Piece extends Vector {
    // written by Qianrui Ma.
    private final Color color;

    Piece(int x, int y, Color color) {
        super(x, y);
        this.color = color;
    }

    public static Piece fromChar(int x, int y, char c) {
        Color color;
        switch (Character.toLowerCase(c)) {
            case 'b':
                color = Blue;
                break;
            case 'w':
                color = White;
                break;
            case 'r':
                color = Red;
                break;
            case 'g':
                color = Green;
                break;
            default:
                throw new IllegalStateException("Unexpected color value: " + Character.toLowerCase(c));
        }
        return new Piece(x, y, color);
    }

    public Color getColor() {
        return color;
    }

    @Override
    Piece copy() {
        return new Piece(getX(), getY(), getColor());
    }
}

