package comp1110.ass2;

import java.util.ArrayList;

public class Shape {
    // written by Qianrui Ma.

    private ArrayList<Piece> points;
    private Vector rect;
    private Vector coordinate;
    private int rotation;
    private String placement;

    Shape(ArrayList<Piece> points, Vector rect) {
        this.points = points;
        this.rect = rect;
        this.coordinate = new Vector(0, 0);
    }

    private Shape(ArrayList<Piece> points, Vector rect, Vector coordinate) {
        this.points = points;
        this.rect = rect;
        this.coordinate = coordinate;
    }

    private ArrayList<Piece> getAbsolutePiece() {
        ArrayList<Piece> absPieces = new ArrayList<>();
        for (Piece p : points) {
            Piece pc = p.copy();
            pc.setX(pc.getX() + coordinate.getX());
            pc.setY(pc.getY() + coordinate.getY());
            absPieces.add(pc);
        }
        return absPieces;
    }

    Shape copy() {
        ArrayList<Piece> newPoints = new ArrayList<>();
        for (Piece p : points) {
            newPoints.add(p.copy());
        }
        return new Shape(newPoints, rect.copy(), coordinate.copy());
    }

    public Vector getCoordinate() {
        return coordinate;
    }

    public void setCoordinate(Vector c) {
        coordinate = c;
    }

    void rotate() {
        // rect exchange
        rect.flip();
        rotation += 90;
        for (Vector point : points) {
            // x y exchange
            point.flip();
            //180% along y
            point.setX(rect.getX() - 1 - point.getX());
        }
    }

    boolean contains(Vector p) {
        for (Vector v : getAbsolutePiece()) {
            if (v.equal(p)) {
                return true;
            }
        }
        return false;
    }

    boolean coexist(Shape other) {
        for (Piece p1 : getAbsolutePiece()) {
            for (Piece p2 : other.getAbsolutePiece()) {
                // if conflict return false
                if (p1.equal(p2) && p1.getColor() != p2.getColor()) {
                    return false;
                }
            }
        }
        return true;
    }

    boolean overlap(Shape other) {
        for (Vector point : getAbsolutePiece()) {
            if (other.contains(point)) {
                return true;
            }
        }
        return false;
    }


    boolean inBoard() {
        for (Vector point : points) {
            int x = point.getX() + coordinate.getX();
            int y = point.getY() + coordinate.getY();
            if ((x < 0 || x > 8) || (y < 0 || y > 4)) {
                return false;
            } else if ((x == 0 && y == 4) || (x == 8 && y == 4)) {
                return false;
            }

        }
        return true;
    }

    public Vector getRect() {
        return rect;
    }

    public String getPlacement() {
        return placement;
    }

    public void setPlacement(String placement) {
        this.placement = placement;
    }

    public int resetRotationTimes(int n) {
        rotation = 0;
        for (int i = 0; i < n; i++) {
            rotate();
        }
        return rotation;
    }

    public int getRotation() {
        return rotation;
    }

}
