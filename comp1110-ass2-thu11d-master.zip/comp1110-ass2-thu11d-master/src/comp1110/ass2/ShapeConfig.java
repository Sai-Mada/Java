package comp1110.ass2;

import java.util.ArrayList;
import java.util.Arrays;

import static comp1110.ass2.Color.*;

public class ShapeConfig {
    // written by Qianrui Ma and modified by Yoav Samocha.

    public static String[] allShapes = new String[]{"a", "b", "c", "d", "e", "f", "g", "h", "i", "j"};
    public static Shape shapeA =
            new Shape(new ArrayList<>(Arrays.asList(
                    new Piece(0, 0, Green),
                    new Piece(1, 0, White),
                    new Piece(2, 0, Red),
                    new Piece(1, 1, Red))),
                    new Vector(3, 2));
    public static Shape shapeB =
            new Shape(new ArrayList<>(Arrays.asList(
                    new Piece(1, 0, Blue),
                    new Piece(2, 0, Green),
                    new Piece(3, 0, Green),
                    new Piece(0, 1, White),
                    new Piece(1, 1, White)
            )),
                    new Vector(4, 2));
    public static Shape shapeC =
            new Shape(new ArrayList<>(Arrays.asList(
                    new Piece(2, 0, Green),
                    new Piece(0, 1, Red),
                    new Piece(1, 1, Red),
                    new Piece(2, 1, White),
                    new Piece(3, 1, Blue)
            )),
                    new Vector(4, 2));
    public static Shape shapeD =
            new Shape(new ArrayList<>(Arrays.asList(
                    new Piece(0, 0, Red),
                    new Piece(1, 0, Red),
                    new Piece(2, 0, Red),
                    new Piece(2, 1, Blue)
            )),
                    new Vector(3, 2));
    public static Shape shapeE =
            new Shape(new ArrayList<>(Arrays.asList(
                    new Piece(0, 0, Blue),
                    new Piece(0, 1, Red),
                    new Piece(1, 0, Blue),
                    new Piece(1, 1, Red),
                    new Piece(2, 0, Blue)
            )),
                    new Vector(3, 2));
    public static Shape shapeF =
            new Shape(new ArrayList<>(Arrays.asList(
                    new Piece(0, 0, White),
                    new Piece(1, 0, White),
                    new Piece(2, 0, White)
            )),
                    new Vector(3, 1));
    public static Shape shapeG =
            new Shape(new ArrayList<>(Arrays.asList(
                    new Piece(0, 0, White),
                    new Piece(1, 0, Blue),
                    new Piece(1, 1, Blue),
                    new Piece(2, 1, White)
            )),
                    new Vector(3, 2));
    public static Shape shapeH =
            new Shape(new ArrayList<>(Arrays.asList(
                    new Piece(0, 0, Red),
                    new Piece(0, 1, White),
                    new Piece(0, 2, White),
                    new Piece(1, 0, Green),
                    new Piece(2, 0, Green)

            )),
                    new Vector(3, 3));
    public static Shape shapeI =
            new Shape(new ArrayList<>(Arrays.asList(
                    new Piece(0, 0, Blue),
                    new Piece(1, 0, Blue),
                    new Piece(1, 1, White)
            )),
                    new Vector(2, 2));
    public static Shape shapeJ =
            new Shape(new ArrayList<>(Arrays.asList(
                    new Piece(0, 0, Green),
                    new Piece(1, 0, Green),
                    new Piece(2, 0, White),
                    new Piece(3, 0, Red),
                    new Piece(0, 1, Green)
            )),
                    new Vector(4, 2));

    public static Shape getChallengeShape(String challenge) {
        Shape shape = new Shape(new ArrayList<>(Arrays.asList(
                Piece.fromChar(0, 0, challenge.charAt(0)),
                Piece.fromChar(1, 0, challenge.charAt(1)),
                Piece.fromChar(2, 0, challenge.charAt(2)),

                Piece.fromChar(0, 1, challenge.charAt(3)),
                Piece.fromChar(1, 1, challenge.charAt(4)),
                Piece.fromChar(2, 1, challenge.charAt(5)),

                Piece.fromChar(0, 2, challenge.charAt(6)),
                Piece.fromChar(1, 2, challenge.charAt(7)),
                Piece.fromChar(2, 2, challenge.charAt(8))
        )),
                new Vector(4, 2));
        shape.setCoordinate(new Vector(3, 1));
        return shape;
    }

    public static ArrayList<Shape> getShapes(String placement) {
        ArrayList<Shape> ss = new ArrayList<>();
        for (int i = 0; i < placement.length(); i += 4) {
            String piecePlacement = placement.substring(i, i + 4);
            Shape s = ShapeConfig.getShape(piecePlacement);
            ss.add(s);
        }
        return ss;
    }


    public static Shape getShape(String placement) {
        Shape s = getShape(placement.charAt(0));
        s.setCoordinate(new Vector(Character.getNumericValue(placement.charAt(1)), Character.getNumericValue(placement.charAt(2))));
        s.resetRotationTimes(Character.getNumericValue(placement.charAt(3)));
        s.setPlacement(placement);
        return s;
    }

    public static Shape getShape(char c) {
        if (c == 'a') {
            return shapeA.copy();
        } else if (c == 'b') {
            return shapeB.copy();
        } else if (c == 'c') {
            return shapeC.copy();
        } else if (c == 'd') {
            return shapeD.copy();
        } else if (c == 'e') {
            return shapeE.copy();
        } else if (c == 'f') {
            return shapeF.copy();
        } else if (c == 'g') {
            return shapeG.copy();
        } else if (c == 'h') {
            return shapeH.copy();
        } else if (c == 'i') {
            return shapeI.copy();
        } else if (c == 'j') {
            return shapeJ.copy();
        }
        return shapeA;
    }

}