package comp1110.ass2.gui;

import comp1110.ass2.FocusGame;
import comp1110.ass2.Shape;
import comp1110.ass2.ShapeConfig;
import comp1110.ass2.Vector;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.SnapshotParameters;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;


/**
 * A very simple viewer for piece placements in the IQ-Focus game.
 * <p>
 * NOTE: This class is separate from your main game class.  This
 * class does not play a game, it just illustrates various piece
 * placements.
 */
public class Viewer extends Application {

    /* board layout */
    private static final int SQUARE_SIZE = 60;
    private static final int VIEWER_WIDTH = 720;
    private static final int VIEWER_HEIGHT = 480;

    private static final String URI_BASE = "assets/";

    private final Group root = new Group();
    private final Group controls = new Group();
    private ArrayList<ImageView> imageViews = new ArrayList<>();
    private TextField textField;

    /**
     * Draw a placement in the window, removing any previously drawn one
     *
     * @param placement A valid placement string
     */
    void makePlacement(String placement) {
        // FIXME Task 4: implement the simple placement viewer
        // written by Yoav Samocha.


        root.getChildren().removeAll(imageViews);
        imageViews.clear();

        for (Shape s : ShapeConfig.getShapes(placement)) {
            // convert shape to imageView
            ImageView i = placeOne(s);
            imageViews.add(i);
        }

        root.getChildren().addAll(imageViews);
    }

    private ImageView placeOne(Shape piece) {
        ImageView imageView = new ImageView();

        String imgPath;
        Vector rect = piece.getRect();
        Vector coordinate = piece.getCoordinate();
        imgPath = URI_BASE + piece.getPlacement().substring(0, 1) + ".png";
        URL url = getClass().getResource(imgPath);

        //Creating an image
        Image image = null;
        try {
            //rotate the image
            ImageView v = new ImageView(new Image(url.openStream()));
            v.setRotate(piece.getRotation());
            //snapshot a rotated image
            SnapshotParameters params = new SnapshotParameters();
            params.setFill(Color.TRANSPARENT);
            image = v.snapshot(params, null);
        } catch (IOException e) {
            e.printStackTrace();
        }

        imageView.setImage(image);
        imageView.setX(coordinate.getX() * SQUARE_SIZE + SQUARE_SIZE);
        imageView.setY(coordinate.getY() * SQUARE_SIZE + SQUARE_SIZE + 15);
        imageView.setFitWidth(rect.getX() * SQUARE_SIZE);
        imageView.setFitHeight(rect.getY() * SQUARE_SIZE);
        return imageView;
    }

    /**
     * Create a basic text field for input and a refresh button.
     */
    private void makeControls() {
        Label label1 = new Label("Placement:");
        textField = new TextField();
        textField.setPrefWidth(300);
        Button button = new Button("Refresh");
        button.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                makePlacement(textField.getText());
                textField.clear();
            }
        });
        HBox hb = new HBox();
        hb.getChildren().addAll(label1, textField, button);
        hb.setSpacing(10);
        hb.setLayoutX(130);
        hb.setLayoutY(VIEWER_HEIGHT - 50);
        controls.getChildren().add(hb);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        primaryStage.setTitle("FocusGame Viewer");
        Scene scene = new Scene(root, VIEWER_WIDTH, VIEWER_HEIGHT);

        drawBoard();
        root.getChildren().add(controls);
        makeControls();

        primaryStage.setScene(scene);
        primaryStage.show();

    }

    private void drawBoard() {
        ImageView imageView = new ImageView();
        String imgPath = URI_BASE + "board.png";
        URL url = getClass().getResource(imgPath);
        Image image;
        try {
            image = new Image(url.openStream());
            imageView.setImage(image);
        } catch (IOException e) {
            e.printStackTrace();
        }
        imageView.setX(20);
        imageView.setFitWidth(620);
        imageView.setFitHeight(400);
        root.getChildren().add(imageView);

//        for (int i = 0; i < 9; i++) {
//            for (int j = 0; j < 5; j++) {
//                if (i == 8 && j == 4 || i == 0 && j == 4) {
//                    continue;
//                }
//                Rectangle rectangle = new Rectangle(i * SQUARE_SIZE + SQUARE_SIZE, j * SQUARE_SIZE + SQUARE_SIZE+15, SQUARE_SIZE, SQUARE_SIZE);
//                rectangle.setFill(Color.TRANSPARENT);
//                rectangle.setStroke(Color.BLACK);
//                root.getChildren().add(rectangle);
//            }
//        }
    }
}
