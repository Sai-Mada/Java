package comp1110.ass2.gui;

import comp1110.ass2.FocusGame;
import comp1110.ass2.Shape;
import comp1110.ass2.ShapeConfig;
import comp1110.ass2.Vector;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.SnapshotParameters;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.TilePane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;

import static comp1110.ass2.ShapeConfig.allShapes;
import static comp1110.ass2.ShapeConfig.getShape;
import static javafx.scene.input.MouseEvent.MOUSE_CLICKED;

public class Board extends Application {

//    private static final int BOARD_WIDTH = 933;
//    private static final int BOARD_HEIGHT = 700;

    // FIXME Task 7: Implement a basic playable Focus Game in JavaFX that only allows pieces to be placed in valid places

    // FIXME Task 8: Implement challenges (you may use challenges and assets provided for you in comp1110.ass2.gui.assets: sq-b.png, sq-g.png, sq-r.png & sq-w.png)

    // FIXME Task 10: Implement hints

    // FIXME Task 11: Generate interesting challenges (each challenge may have just one solution)
    /* board layout */

    // written by Qianrui Ma and modified from the code from task 4(from Yoav Samocha).

    private static final int SQUARE_SIZE = 60;
    private static final int BOARD_WIDTH = 933;
    private static final int BOARD_HEIGHT = 700;
    private static final String URI_BASE = "assets/";
    private final Group root = new Group();
    private final Group controls = new Group();
    private ArrayList<Shape> boardShapes = new ArrayList<>();
    private ArrayList<ImageView> imageViews = new ArrayList<>();
    private ImageView piecePreview;
    private String currentShapeName;
    private ObservableList<String> pieceOptions;
    private int currentRotation;
    private ComboBox<String> box;

    private Vector getBoardPlace(int x, int y) {
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 5; j++) {
                if (i == 8 && j == 4 || i == 0 && j == 4) {
                    continue;
                }
                Rectangle rectangle = new Rectangle(i * SQUARE_SIZE + SQUARE_SIZE, j * SQUARE_SIZE + SQUARE_SIZE + 15, SQUARE_SIZE, SQUARE_SIZE);
                rectangle.setFill(Color.TRANSPARENT);
                rectangle.setStroke(Color.BLACK);
                if ((between(x, i * SQUARE_SIZE + SQUARE_SIZE, (i + 1) * SQUARE_SIZE + SQUARE_SIZE)) &&
                        (between(y, (j * SQUARE_SIZE) + SQUARE_SIZE + 15, ((j + 1) * SQUARE_SIZE) + SQUARE_SIZE + 15))) {
                    return new Vector(i, j);
                }
            }
        }
        return null;
    }

    private boolean between(int t, int begin, int end) {
        return (t >= begin) && (t <= end);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        primaryStage.setTitle("FocusGame");
        Scene scene = new Scene(root, BOARD_WIDTH, BOARD_HEIGHT);
        currentShapeName = "a";
        currentRotation = 0;
        pieceOptions = FXCollections.observableArrayList(allShapes);

        drawBoard();
        makeControls();
        root.getChildren().add(controls);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void setMouseEvent() {
        EventHandler<MouseEvent> eventHandler = e -> {
            int x = (int) e.getX();
            int y = (int) e.getY();
            Vector boardPlace = getBoardPlace(x, y);
            if (boardPlace != null) {
                String placement = currentShapeName + boardPlace.getX() + boardPlace.getY() + currentRotation;
                makePlacement(placement);
            }
        };
        root.addEventHandler(MOUSE_CLICKED, eventHandler);
    }

    private TilePane getComboBox() {

        box = new ComboBox<>(pieceOptions);
        Label selected = new Label("select a shape");

        EventHandler<ActionEvent> event = e -> {
            currentShapeName = box.getValue();
            selected.setText("shape <" + box.getValue() + "> selected");
            updatePreview();
        };
        box.setOnAction(event);
        box.setValue("a");
        selected.setText("shape <" + box.getValue() + "> selected");


        Button rotateButton = new Button("rotate");
        rotateButton.setOnAction(e1 -> {
            currentRotation = (currentRotation + 1) % 4;
            updatePreview();
        });

        Button resetButton = new Button("reset board");
        resetButton.setOnAction(e -> {
            clearBoard();
            updatePreview();
        });

        TilePane tilePane = new TilePane(box, selected);
        tilePane.setLayoutY(410);

        tilePane.getChildren().add(rotateButton);
        tilePane.getChildren().add(resetButton);
        updatePreview();
        return tilePane;
    }

    /**
     * Draw the preview piece on the board
     */
    private void updatePreview() {
        root.getChildren().remove(piecePreview);
        if (currentShapeName != null) {
            Shape s = getShape(currentShapeName.charAt(0));
            int rotation = s.resetRotationTimes(currentRotation);
            Vector rect = s.getRect();
            int width = rect.getX() * SQUARE_SIZE;
            int height = rect.getY() * SQUARE_SIZE;
            piecePreview = getImageView(currentShapeName, rotation, 200, 440, width, height);
            root.getChildren().add(piecePreview);
        }
    }

    /**
     * Draw a placement in the window, removing any previously drawn one
     *
     * @param placement A valid placement string
     */
    private void makePlacement(String placement) {
        StringBuilder allPlacement = new StringBuilder();
        for (Shape s : boardShapes) {
            allPlacement.append(s.getPlacement());
        }

        if (!FocusGame.isPlacementStringWellFormed(allPlacement + placement) || !FocusGame.isPlacementStringValid(allPlacement + placement)) {
            return;
        }

        clearBoard();
        for (Shape s : ShapeConfig.getShapes(allPlacement + placement)) {
            // convert shape to imageView
            boardShapes.add(s);
            ImageView i = placeOne(s);
            imageViews.add(i);
            root.getChildren().add(i);
            pieceOptions.removeIf(e -> e.equals(s.getPlacement().substring(0, 1)));
        }
        currentShapeName = pieceOptions.get(0);
        updateBoxOptions();
    }

    private void clearBoard() {
        root.getChildren().removeAll(imageViews);
        boardShapes.clear();
        imageViews.clear();
        pieceOptions = FXCollections.observableArrayList(allShapes);
        updateBoxOptions();
    }

    private void updateBoxOptions() {
        box.setValue(null);
        box.setItems(pieceOptions);
        box.setValue(pieceOptions.get(0));
    }


    private ImageView placeOne(Shape piece) {

        Vector coordinate = piece.getCoordinate();
        String shapeName = piece.getPlacement().substring(0, 1);
        int rotation = piece.getRotation();
        int x = coordinate.getX() * SQUARE_SIZE + SQUARE_SIZE;
        int y = coordinate.getY() * SQUARE_SIZE + SQUARE_SIZE + 15;

        Vector rect = piece.getRect();
        int width = rect.getX() * SQUARE_SIZE;
        int height = rect.getY() * SQUARE_SIZE;

        return getImageView(shapeName, rotation, x, y, width, height);
    }

    private ImageView getImageView(String shapeName, int rotation, int x, int y, int width, int height) {
        String imgPath = URI_BASE + shapeName + ".png";
        URL url = getClass().getResource(imgPath);
        //Creating an image
        Image image = null;
        try {
            //rotate the image
            ImageView v = new ImageView(new Image(url.openStream()));
            v.setRotate(rotation);
            //snapshot a rotated image
            SnapshotParameters params = new SnapshotParameters();
            params.setFill(Color.TRANSPARENT);
            image = v.snapshot(params, null);
        } catch (IOException e) {
            e.printStackTrace();
        }

        ImageView imageView = new ImageView();
        imageView.setImage(image);
        imageView.setX(x);
        imageView.setY(y);
        imageView.setFitWidth(width);
        imageView.setFitHeight(height);
        return imageView;
    }


    /**
     * Create a basic combobox and buttons
     */
    private void makeControls() {
        setMouseEvent();
        controls.getChildren().add(getComboBox());
    }

    private void drawBoard() {
        ImageView imageView = new ImageView();
        String imgPath = URI_BASE + "board.png";
        URL url = getClass().getResource(imgPath);
        Image image;
        try {
            image = new Image(url.openStream());
            imageView.setImage(image);
        } catch (IOException e) {
            e.printStackTrace();
        }
        imageView.setX(20);
        imageView.setFitWidth(620);
        imageView.setFitHeight(400);
        root.getChildren().add(imageView);
    }
}

