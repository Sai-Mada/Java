# COMP1110 Assignment 2 Group Tasks

For each task or sub-task, record who is responsible, the deadline, and any dependencies.
Use the entries below as an example.

## Week 4

Everyone: create application skeleton - meeting 17:00 18 Aug

## Week 5


## Week 6

...

## Mid-Semester Break

## Week 7

## Week 8

## Week 9

## Week 10

## Week 11

Contact:
- Qianrui Ma on messenger u6361341@anu.edu.au
- Sai Mada on messenger, u6080333@anu.edu.au
- Yoav Samocha on Facebook/messenger, u6940492@anu.edu.au
