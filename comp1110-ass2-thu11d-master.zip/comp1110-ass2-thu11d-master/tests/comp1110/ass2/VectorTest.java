package comp1110.ass2;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class VectorTest {

    @Test
    public void getX() {
        Vector vector = new Vector(1, 1);
        assertEquals(1, vector.getX());
    }

    @Test
    public void setX() {
        Vector vector = new Vector(1, 1);
        vector.setX(10);
        assertEquals(10, vector.getX());
    }

    @Test
    public void getY() {
        Vector vector = new Vector(1, 1);
        assertEquals(1, vector.getY());
    }

    @Test
    public void setY() {
        Vector vector = new Vector(1, 1);
        vector.setY(10);
        assertEquals(10, vector.getY());
    }

    @Test
    public void copy() {
        Vector vector = new Vector(1, 1);
        Vector vectorCp = new Vector(1, 1);
        assertEquals(vectorCp.getX(), vector.getX());
        assertEquals(vectorCp.getY(), vector.getY());

        vectorCp.setX(10);
        assertEquals(1, vector.getX());
        assertEquals(10, vectorCp.getX());

        vector.setY(10);
        assertEquals(10, vector.getY());
        assertEquals(1, vectorCp.getY());
    }

    @Test
    public void flip() {
        Vector vector = new Vector(1, 2);
        assertEquals(1, vector.getX());
        assertEquals(2, vector.getY());
        vector.flip();
        assertEquals(2, vector.getX());
        assertEquals(1, vector.getY());
    }

    @Test
    public void equal() {
        Vector vector = new Vector(1, 2);
        Vector vector1 = new Vector(1, 2);
        assertTrue(vector.equal(vector1));
    }

    @Test
    public void testToString() {
        Vector vector = new Vector(1, 2);
        assertEquals(vector.toString(), "(x: 1, y: 2)");
    }
}