package comp1110.ass2;

        import org.junit.Assert;
        import org.junit.Test;

        import java.util.Random;

public class SaiTests {

    @Test
    public void testUnique(){

        // the random class object to produce random numbers
        Random random = new Random();

        // generate a random value for 'N' in the range 1-10
        int N = random.nextInt(10) + 1;

        // the first character is in the range a .. j (shape)
        String pieces = "abcdefghij";

        // the second character is in the range 0 .. 8 (column)
        // the third character is in the range 0 .. 4 (row)
        // the fourth character is in the range 0 .. 3 (orientation)
        int col, row, orientation;

        // The stringbuilder will build the placement string for us
        StringBuilder stringBuilder = new StringBuilder();

        // loop N times so that the placement string has N piece placements
        for (int i = 0; i < N; i++){
            char x = ' ';

            // select a random shape and remove it from the 'pieces' string so that we only get unique shapes
            while (x == ' '){
                x = pieces.charAt(random.nextInt(pieces.length()));
            }
            pieces = pieces.replace(x, ' ');
            stringBuilder.append(x);

            // pick a random column number and append it to the string builder
            col = random.nextInt(9);
            stringBuilder.append(col);

            // pick a random row number and append it to the string builder
            row = random.nextInt(5);
            stringBuilder.append(row);

            // pick a random orientation number and append it to the string builder
            orientation = random.nextInt(4);
            stringBuilder.append(orientation);
        }

        // convert the string builder into string
        String valid = stringBuilder.toString();
        // check if function isPlacementStringWellFormed returns true for this valid placement string or not
        Assert.assertTrue(FocusGame.isPlacementStringWellFormed(valid));

        // if more than one piece is generated add a shape that is already in the placementString to
        // check if the function detects duplicate
        if (valid.length() > 4){
            // verify if the function isPlacementStringWellFormed returns false for this invalid placement string or not
            Assert.assertFalse(FocusGame.isPlacementStringWellFormed(valid.concat(valid.charAt(0)+"")));
        }

    }
}