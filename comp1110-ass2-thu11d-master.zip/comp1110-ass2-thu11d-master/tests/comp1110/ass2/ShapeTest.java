package comp1110.ass2;

import org.junit.Assert;
import org.junit.Test;

public class ShapeTest {

    @Test
    public void copy() {
        Shape a = ShapeConfig.getShape('a');
        Shape aC = a.copy();
        Assert.assertTrue(new Vector(0, 0).equal(a.getCoordinate()));
        a.setCoordinate(new Vector(3, 3));
        Assert.assertTrue(new Vector(3, 3).equal(a.getCoordinate()));
        Assert.assertTrue(new Vector(0, 0).equal(aC.getCoordinate()));

    }

    @Test
    public void getCoordinate() {
        Shape a = ShapeConfig.getShape('a');
        Assert.assertTrue(new Vector(0, 0).equal(a.getCoordinate()));
    }

    @Test
    public void setCoordinate() {
        Shape a = ShapeConfig.getShape('a');
        Assert.assertTrue(new Vector(0, 0).equal(a.getCoordinate()));
        a.setCoordinate(new Vector(3, 3));
        Assert.assertTrue(new Vector(3, 3).equal(a.getCoordinate()));
    }

    @Test
    public void rotate() {
        Shape a = ShapeConfig.getShape('a');
        Assert.assertEquals(0, a.getRotation());
        a.rotate();
        a.rotate();
        Assert.assertEquals(2 * 90, a.getRotation());
    }

    @Test
    public void contains() {
        Shape a = ShapeConfig.getShape('a');
        Assert.assertTrue(a.contains(new Vector(0, 0)));
        Assert.assertFalse(a.contains(new Vector(3, 3)));
        Assert.assertFalse(a.contains(new Vector(4, 4)));
        a.setCoordinate(new Vector(3, 3));
        Assert.assertFalse(a.contains(new Vector(0, 0)));
        Assert.assertTrue(a.contains(new Vector(3, 3)));
        Assert.assertTrue(a.contains(new Vector(4, 4)));
    }

    @Test
    public void coexist() {
        Shape a = ShapeConfig.getShape('a');
        Shape d = ShapeConfig.getShape('d');
        d.setCoordinate(new Vector(2, 0));
        Assert.assertTrue(a.overlap(d));
        Assert.assertTrue(a.coexist(d));
        d.setCoordinate(new Vector(1, 0));
        Assert.assertTrue(a.overlap(d));
        Assert.assertFalse(a.coexist(d));
    }

    @Test
    public void overlap() {
        Shape a = ShapeConfig.getShape('a');
        Shape b = ShapeConfig.getShape('b');
        Assert.assertTrue(a.overlap(b));
        b.setCoordinate(new Vector(3, 3));
        Assert.assertFalse(a.overlap(b));
    }

    @Test
    public void inBoard() {
        Shape a = ShapeConfig.getShape('a');
        Assert.assertTrue(a.inBoard());
        a.setCoordinate(new Vector(9, 9));
        Assert.assertFalse(a.inBoard());
    }

    @Test
    public void getRect() {
        Assert.assertTrue(ShapeConfig.getShape('a').getRect().equal(new Vector(3, 2)));
        Assert.assertTrue(ShapeConfig.getShape('b').getRect().equal(new Vector(4, 2)));
        Assert.assertTrue(ShapeConfig.getShape('c').getRect().equal(new Vector(4, 2)));
        Assert.assertTrue(ShapeConfig.getShape('d').getRect().equal(new Vector(3, 2)));
    }


    @Test
    public void setPlacement() {
        Shape a = ShapeConfig.getShape('a');
        a.setPlacement("a001");
        Assert.assertEquals("a001", a.getPlacement());

        Shape b = ShapeConfig.getShape('b');
        b.setPlacement("b011");
        Assert.assertEquals("b011", b.getPlacement());
    }

    @Test
    public void resetRotationTimes() {
        Shape a = ShapeConfig.getShape('a');
        a.resetRotationTimes(3);
        Assert.assertEquals(3 * 90, a.getRotation());
        a.resetRotationTimes(2);
        Assert.assertEquals(2 * 90, a.getRotation());
    }

    @Test
    public void getRotation() {
        Shape a = ShapeConfig.getShape('a');
        a.resetRotationTimes(3);
        Assert.assertEquals(3 * 90, a.getRotation());
    }
}