package comp1110.ass2;

import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;

import static org.junit.Assert.*;

public class ShapeConfigTest {
    @Test
    // Tests if getPiece test correctly extracts shape
    // from string placement
    public void getPieceTest() {
        Shape s = ShapeConfig.getShape("a000");
        Shape ans = ShapeConfig.shapeA;
        System.out.println(ans.equals(s));


    }

    @Test
    // Tests adding shapes to array
    public void getPiecesTest() {
        ArrayList <Shape> ss = new ArrayList<>();
        String piecePlacement = "a000";
        Shape s = ShapeConfig.getShape(piecePlacement);
        ss.add(s);
        System.out.println(ShapeConfig.shapeA.equals(s));

    }

    @Test
    // Tests if correct shape is attributed to each char
    public void getShapeTest() {
        Shape s = ShapeConfig.shapeA;
        System.out.println(ShapeConfig.getShape('a').equals(s));
        Shape incorrect = ShapeConfig.shapeB;
        assertNotEquals(incorrect,ShapeConfig.getShape('a'));

    }
}